# PAM Tracker Proxy

Proxy server per Timenet PAM Tracker 2026.

## Deploy su Railway
1. Crea un repo GitHub con questi file
2. Vai su railway.app → New Project → Deploy from GitHub repo
3. Railway detecta automaticamente Node.js e fa il deploy
4. Copia l'URL pubblico generato da Railway
